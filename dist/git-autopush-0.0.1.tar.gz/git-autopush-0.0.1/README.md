# git-autopush
A python package to automate basic git functions.
